#ifndef MENU_H
#define MENU_H

class Menu {
public:
    void display();

private:
    void optionOne();
    void optionTwo();
    void optionThree();
    void optionFour();
};

#endif // MENU_H
