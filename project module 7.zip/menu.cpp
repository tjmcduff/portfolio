#include <iostream>
#include <fstream>
#include <map>
#include "menu.h"

using namespace std;

void Menu::display() {
    int choice;
    do {
        cout << "Please choose an option:" << endl;
        cout << "1. Look up an item" << endl;
        cout << "2. Show frequency of all items" << endl;
        cout << "3. Show histogram of all items" << endl;
        cout << "4. Exit" << endl;
        cin >> choice;
        switch (choice) {
        case 1:
            optionOne();
            break;
        case 2:
            optionTwo();
            break;
        case 3:
            optionThree();
            break;
        case 4:
            optionFour();
            break;
        default:
            cout << "Invalid choice, please try again" << endl;
            break;
        }
    } while (choice != 4);
}

void Menu::optionOne() {
    string item;
    cout << "Enter item to look up: ";
    cin >> item;
    ifstream inputFile("CS210_Project_Three_Input_File.txt");
    if (!inputFile) {
        cout << "Error: Could not open file" << endl;
        return;
    }
    string word;
    int frequency = 0;
    while (inputFile >> word) {
        if (word == item) {
            frequency++;
        }
    }
    inputFile.close();
    cout << item << " appears " << frequency << " times" << endl;
}

void Menu::optionTwo() {
    ifstream inputFile("CS210_Project_Three_Input_File.txt");
    if (!inputFile) {
        cout << "Error: Could not open file" << endl;
        return;
    }
    map<string, int> frequencyMap;
    string word;
    while (inputFile >> word) {
        frequencyMap[word]++;
    }
    inputFile.close();
    for (auto const& [key, value] : frequencyMap) {
        cout << key << " " << value << endl;
    }
}

void Menu::optionThree() {
    ifstream inputFile("CS210_Project_Three_Input_File.txt");
    if (!inputFile) {
        cout << "Error: Could not open file" << endl;
        return;
    }
    map<string, int> frequencyMap;
    string word;
    while (inputFile >> word) {
        frequencyMap[word]++;
    }
    inputFile.close();
    for (auto const& [key, value] : frequencyMap) {
        cout << key << " ";
        for (int i = 0; i < value; i++) {
            cout << "*";
        }
        cout << endl;
    }
}

void Menu::optionFour() {
    cout << "Exiting program" << endl;
}
