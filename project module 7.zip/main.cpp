#include <iostream>
#include "menu.h"

int main() {
    Menu menu;
    menu.display();
    return 0;
}
